/**
 * 
 */
package com.royalmail.validate;

import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author Arvind Nadimpally
 *
 */
@Controller
public class ValidateController {
	
	private static final int[] CHECK_DIGIT = {8, 6, 4, 2, 3, 5, 9, 7};
	
	private static final int MOD_VALUE = 11;

	@RequestMapping(method = RequestMethod.POST, value="/validate")
	@ResponseBody
	public boolean validateS10Barcode(@RequestBody String ID) {
		
		boolean s10Validate = true;
		System.out.println("In Validate Method ::: " + ID);
		JSONObject josonObj = new JSONObject(ID);
		String s10Barcode = josonObj.getString("ID");
		if(s10Barcode.length() != 13) {
			s10Validate = false;
			return s10Validate;
		}
		s10Validate = validateS10(s10Barcode);
		if(s10Validate == true) {
			return calculateCheckDigit(s10Barcode);
		}
		return s10Validate;
	}
	
	public boolean validateS10(String s10) {
		String first2Characters = s10.substring(0,2);
		for(int i=0; i< first2Characters.length(); i++) {
			if((Character.isLetter(first2Characters.charAt(i))
					&& Character.isUpperCase(first2Characters.charAt(i))) == false) {
				return false;
			}
		}
		if(!s10.substring(11,13).equals("GB")) {
			return false;
		}
		String isNumber = s10.substring(2,11);
		for(int j=0; j<isNumber.length(); j++) {
			if(Character.isDigit(isNumber.charAt(j)) == false) {
				return false;
			}
		}
		return true;
	}
	
	public boolean calculateCheckDigit(String s10Barcode) {
		boolean isCheckDigit = false;
		String numberString = s10Barcode.substring(2,10);
		String s10Digits = s10Barcode.substring(2,10);
		int sum = 0;
		for (int i = 0; i < numberString.length(); i++) { 
			sum = sum + Character.digit(s10Digits.charAt(i),10) * CHECK_DIGIT[i];
		}
		int finalCheck = MOD_VALUE - (sum % MOD_VALUE);
		if(finalCheck == 10) {
			finalCheck = 0;
		} else if(finalCheck == 11) {
			finalCheck = 5;
		}
		if(finalCheck == Integer.parseInt(s10Barcode.substring(10,11))) {
			isCheckDigit = true;
		}
		return isCheckDigit;
	}

}
