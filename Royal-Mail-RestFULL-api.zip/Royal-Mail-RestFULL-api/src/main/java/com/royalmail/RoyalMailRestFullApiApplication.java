package com.royalmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.royalmail.validate"})
public class RoyalMailRestFullApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoyalMailRestFullApiApplication.class, args);
	}

}
