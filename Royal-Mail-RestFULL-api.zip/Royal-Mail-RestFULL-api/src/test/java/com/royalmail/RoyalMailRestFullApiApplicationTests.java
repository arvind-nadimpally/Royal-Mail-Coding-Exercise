package com.royalmail;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.royalmail.validate.ValidateController;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RoyalMailRestFullApiApplicationTests {
	
	@Autowired
	ValidateController validator;
	
	@Test
	public void validateS10Barcode_wheninvalidS10Barcode() {
		String s10Barcode = "A1121134294GB";
	    boolean result = validator.validateS10(s10Barcode);
	    assertEquals(false, result);
	}
	
	@Test
	public void validateS10Barcode_whenvalidS10Barcode() {
		String s10Barcode = "AA473124829GB";
	    boolean result = validator.validateS10(s10Barcode);
	    assertEquals(true, result);
	}
	
	@Test
	public void calculateS10Barcode_whenvalidS10Barcode() {
		String s10Barcode = "AA473124829GB";
	    boolean result = validator.calculateCheckDigit(s10Barcode);
	    assertEquals(true, result);
	}
	
	@Test
	public void calculateS10Barcode_wheninvalidS10Barcode() {
		String s10Barcode = "AA474524829GB";
	    boolean result = validator.calculateCheckDigit(s10Barcode);
	    assertEquals(false, result);
	}

}
